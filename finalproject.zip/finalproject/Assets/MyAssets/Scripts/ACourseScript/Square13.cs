﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

public class Square13 : MonoBehaviour {

[SerializeField]
public TextMeshProUGUI playerDirectionText;



	// Use this for initialization
	void Start () {
		

	}
	public void OnTriggerEnter(Collider other){
	if (other.gameObject.tag=="player")
	{
	playerDirectionText.text="SDGsの活動が拡大する\n\n200コイン獲得";

	}
	}
}
