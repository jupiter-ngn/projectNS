﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

public class Square9 : MonoBehaviour {

[SerializeField]
public TextMeshProUGUI playerDirectionText;



	// Use this for initialization
	void Start () {
		

	}
	public void OnTriggerEnter(Collider other){
	if (other.gameObject.tag=="player")
	{
	playerDirectionText.text="カーシェアリングの普及\n\n100コイン獲得";

	}
	}
}
