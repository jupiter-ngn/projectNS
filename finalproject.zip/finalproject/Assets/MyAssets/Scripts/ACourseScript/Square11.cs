﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

public class Square11 : MonoBehaviour {

[SerializeField]
public TextMeshProUGUI playerDirectionText;



	// Use this for initialization
	void Start () {
		

	}
	public void OnTriggerEnter(Collider other){
	if (other.gameObject.tag=="player")
	{
	playerDirectionText.text="エコプロダクトの拡大など市民の消費意識が変わる\n\n1マスすすむ";

	}
	}
}
