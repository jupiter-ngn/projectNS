﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

public class Square10 : MonoBehaviour {

[SerializeField]
public TextMeshProUGUI playerDirectionText;



	// Use this for initialization
	void Start () {
		

	}
	public void OnTriggerEnter(Collider other){
	if (other.gameObject.tag=="player")
	{
	playerDirectionText.text="電気自動車の普及により大気汚染が改善される\n\n200コイン獲得&2マスすすむ";

	}
	}
}

