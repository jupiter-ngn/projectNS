﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

public class Square2 : MonoBehaviour {

	
[SerializeField]
public TextMeshProUGUI playerDirectionText;



	// Use this for initialization
	void Start () {
		

	}
	public void OnTriggerEnter(Collider other){
	if (other.gameObject.tag=="player")
	{
	playerDirectionText.text="FITがはじまる\n\n200コイン獲得&2マスすすむ";

	}
	}
	
	// Update is called once per frame
	void Update () {
		
	}
}
