﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

public class Square1 : MonoBehaviour {

[SerializeField]
public TextMeshProUGUI playerDirectionText;



	// Use this for initialization
	void Start () {
		playerDirectionText.text="サイコロをふってください";

	}
	public void OnTriggerEnter(Collider other){
	if (other.gameObject.tag=="player")
	{
	playerDirectionText.text="楽しくGlobal warmingをまなびましょう！\n\n3マス進む";

	}
	}
	
	// Update is called once per frame
	void Update () {
		
	}
}
