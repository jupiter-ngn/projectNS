﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using TMPro;

public class Level2Branch : MonoBehaviour {

[SerializeField]
public TextMeshProUGUI playerDirectionText;



	// Use this for initialization
	void Start () {
		

	}
	public void OnTriggerEnter(Collider other){
	if (other.gameObject.tag=="player")
	{
	playerDirectionText.text="Level1クリアです。おめでとう!!\n\nAコースとBコースのどちらかを選んでください";

	}
	}
	
}
