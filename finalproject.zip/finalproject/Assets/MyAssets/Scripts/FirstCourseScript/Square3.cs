﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

public class Square3 : MonoBehaviour {

[SerializeField]
public TextMeshProUGUI playerDirectionText;



	// Use this for initialization
	void Start () {
		

	}
	public void OnTriggerEnter(Collider other){
	if (other.gameObject.tag=="player")
	{
	playerDirectionText.text="化石燃料発電所が建設される\n\nスタートにもどる";

	}
	}
	
	// Update is called once per frame
	void Update () {
		
	}

}
