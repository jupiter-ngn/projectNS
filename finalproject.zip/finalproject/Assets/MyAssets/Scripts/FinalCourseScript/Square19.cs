﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

public class Square19 : MonoBehaviour {

[SerializeField]
public TextMeshProUGUI playerDirectionText;



	// Use this for initialization
	void Start () {
		

	}
	public void OnTriggerEnter(Collider other){
	if (other.gameObject.tag=="player")
	{
	playerDirectionText.text="工場の爆発で化学物質がふる\n\n300コイン没収&3マスさがる";

	}
	}
}
