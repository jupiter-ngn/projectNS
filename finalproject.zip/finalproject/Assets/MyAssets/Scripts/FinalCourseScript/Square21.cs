﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using TMPro;

public class Square21 : MonoBehaviour {
	

[SerializeField]
public TextMeshProUGUI playerDirectionText;


	// Use this for initialization
	void Start () {
		

	}
	public void OnTriggerEnter(Collider other){
	if (other.gameObject.tag=="player")
	{
	playerDirectionText.text="おめでとう。ゴールです!!";
	
	}

	Invoke("Call", 3f);
	}

    void Call ()
    {
		SceneManager.LoadScene("results");
		
	}
	

}
