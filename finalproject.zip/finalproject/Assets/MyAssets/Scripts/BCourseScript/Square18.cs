﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

public class Square18 : MonoBehaviour {

[SerializeField]
public TextMeshProUGUI playerDirectionText;



	// Use this for initialization
	void Start () {
		

	}
	public void OnTriggerEnter(Collider other){
	if (other.gameObject.tag=="player")
	{
	playerDirectionText.text="排出権取引制度がはじまる\n\n200コイン獲得";

	}
	}
}

