﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

public class Square16 : MonoBehaviour {

[SerializeField]
public TextMeshProUGUI playerDirectionText;



	// Use this for initialization
	void Start () {
		

	}
	public void OnTriggerEnter(Collider other){
	if (other.gameObject.tag=="player")
	{
	playerDirectionText.text="エアコンの温度を1度上げる\n\n100コイン獲得";

	}
	}
}
