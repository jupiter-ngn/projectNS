﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

public class Square14 : MonoBehaviour {

[SerializeField]
public TextMeshProUGUI playerDirectionText;



	// Use this for initialization
	void Start () {
		

	}
	public void OnTriggerEnter(Collider other){
	if (other.gameObject.tag=="player")
	{
	playerDirectionText.text="ホッキョクグマの頭数が減る\n\n100コイン没収&1マスさがる";

	}
	}
}
