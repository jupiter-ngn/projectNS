﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class ButtonManagement : MonoBehaviour {
public void OnClickButton()
{
	//Debug.Log("Click Button");
	SceneManager.LoadScene("main");
}

	
}
