﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class testCol : MonoBehaviour {


 void OnCollisionEnter (Collision col)
    {
		Debug.Log("called" + col.gameObject.name);
    }

	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		
	}
}
